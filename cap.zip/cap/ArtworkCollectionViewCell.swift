 //
//  ArtworkCollectionViewCell.swift
//  cap
//
//  Created by ZAIRE FRAZIER on 11/26/19.
//  Copyright © 2019 Zai.Eli.Fra LLc. All rights reserved.
//

import UIKit

class ArtworkCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    
}
