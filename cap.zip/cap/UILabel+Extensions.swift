//
//  UILabel+Extensions.swift
//  cap
//
//  Created by ZAIRE FRAZIER on 11/26/19.
//  Copyright © 2019 Zai.Eli.Fra LLc. All rights reserved.
//

import Foundation
import UIKit

extension UILabel{
  

  func showText(_ text: String, andHideAfter delay: Double){
    
    DispatchQueue.main.async {
      
      self.text = text
      self.alpha = 1
      UIView.animate(withDuration: delay, animations: { self.alpha = 0 } )
    }
    
  }
}
