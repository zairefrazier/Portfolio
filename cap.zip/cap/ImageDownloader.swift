//
//  ImageDownloader.swift
//  cap
//
//  Created by ZAIRE FRAZIER on 11/26/19.
//  Copyright © 2019 Zai.Eli.Fra LLc. All rights reserved.
//
import Foundation
import UIKit
import ARKit

enum FileSuffix {
  
  case JPEG, PNG

  var name: String{
    switch self {
    case .JPEG: return ".jpg"
    case .PNG:  return ".png"
    }
  }
}

struct ReferenceImagePayload{
  
  var name: String
  var extensionType: String
  var orientation: CGImagePropertyOrientation
  var widthInM: CGFloat
  
}

class ImageDownloader{
  
    
    
    
    
  typealias completionHandler = (Result<Set<ARReferenceImage>, Error>) -> ()
  typealias ImageData = (image: UIImage, orientation: CGImagePropertyOrientation, physicalWidth: CGFloat, name: String)
  
  static let BASE_PATH = "http://smvrtgallery.com/wp-content/uploads/2019/12/"

  static let payloadData: [ReferenceImagePayload] = [
    ReferenceImagePayload(name: "The_Old_Guitarist", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "portrait-of-aunt-pepa-1896", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "the-weeping-woman", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "Les_Demoiselles_d27Avignon", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "self-portrait", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "Water-lilies", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "Whistler-Mother", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Kiss", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Last-Supper", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-School-of-Athens", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "the-third-of-may", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "Van-Gogh-Self-Portrait", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Night-Watch", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Storm-On-The-Sea-Of-Galilee", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Starry-Night", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Sleeping-Gypsy", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Persistence-of-Memory", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "Massacre-Of-The-Innocents", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
    ReferenceImagePayload(name: "The-Creation-of-Adam", extensionType: FileSuffix.JPEG.name, orientation: .up, widthInM: 1),
  ]
  
  static var receivedImageData = [ImageData]()

  class func downloadImagesFromPaths(_ completion: @escaping completionHandler) {
    
    let operationQueue = OperationQueue()
    
    operationQueue.maxConcurrentOperationCount = 6
    
    let completionOperation = BlockOperation {
      
      OperationQueue.main.addOperation({
        
        completion(.success(referenceImageFrom(receivedImageData)))
        
      })
    }
    
    payloadData.forEach { (payload) in
      
      guard let url = URL(string: BASE_PATH + payload.name + payload.extensionType) else { return }
      
      let operation = BlockOperation(block: {
        
        do{
          
          let imageData = try Data(contentsOf: url)
          
          if let image = UIImage(data: imageData){
            
            receivedImageData.append(ImageData(image, payload.orientation, payload.widthInM, payload.name))
          }
          
        }catch{
          
          completion(.failure(error))
        }
        
      })
      
      completionOperation.addDependency(operation)
      
    }
    
    operationQueue.addOperations(completionOperation.dependencies, waitUntilFinished: false)
    operationQueue.addOperation(completionOperation)
    
  }
  

  class func referenceImageFrom(_ downloadedData: [ImageData]) -> Set<ARReferenceImage>{
    
    var referenceImages = Set<ARReferenceImage>()
    
    downloadedData.forEach {
      
      guard let cgImage = $0.image.cgImage else { return }
      let referenceImage = ARReferenceImage(cgImage, orientation: $0.orientation, physicalWidth: $0.physicalWidth)
      referenceImage.name = $0.name
      referenceImages.insert(referenceImage)
    }
    
    return referenceImages
    
  }
  
}
